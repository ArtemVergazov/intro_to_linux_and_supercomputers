#!/usr/bin/bash
hostname
echo
env | grep SLURM
date
