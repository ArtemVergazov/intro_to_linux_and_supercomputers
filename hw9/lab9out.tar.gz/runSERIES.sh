#!/usr/bin/bash

time="2:00"
mem=1G
queue=cpu
outfile="PImpi_P"

for tasks in 2 4 8
do
    nodes=$tasks
    for ((cpus=1; cpus < 17; cpus*=2))
    do
        mincpus=$((cpus+0))
        echo "submit -p $queue --output=${outfile}-${tasks}_${cpus}.out -N $nodes -n $tasks -c $cpus --mincpus=$mincpus --mem=$mem --time=$time"

        sbatch -J PI-${tasks}-${cpus} -p $queue --output=${outfile}-${tasks}_${cpus}.out -N $nodes -n $tasks -c $cpus \
                                                --mincpus=$mincpus --mem=$mem --time=$time runPImpi.sh 10
        sleep 5
    done
done
echo END

