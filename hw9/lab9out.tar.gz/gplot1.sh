#!/usr/bin/bash

for mpi in 2 4 8
do

infile=PImpi_P-${mpi}
outfile=all_${mpi}.out

cat ${infile}_* | awk 'BEGIN{ k=1; }
                        /MASTER/{   i = $10+0;  j = $11+0;
                                    if( rt[j] == 0 ) rt[j] = 100000.0;
                                    if( rt[j] > $13 && $15 > 0) {
                                        rt[j] = $13; pi[j] = $15; dpi[j] = 100.0*$17/pi[j];
                                        omp[k]=j+0;
                                        #print k, "OMP ", omp[k], "MPI ", i "RT ", rt[j];
                                        k++;
                                    }
                                }
                        END {
                                n = asorti(omp,somp,"@val_type_asc");
                                printf "#  %d MPI %d\n", n, i;
                                for(j=1; j<=n; j++) {
                                    ompdx = omp[somp[j]];
                                    printf "%d %f\n", ompdx, rt[ompdx];
                                }
                        }'   >$outfile

done

gnuplot <<EOF
set logscale xy
set size 1,1
set origin 0,0
set terminal x11 font "Helvetica, 12"
#set terminal png font "Helvetica, 12"
#set output "lab9.png"

set xlabel "number of OMP threads"
set xrange [1:20]
set xtics 2
set ylabel "Elapsed time [seconds]"
#set yrange [100:10000]
set ytics 2

plot "all_2.out" using 1:2 title "MPI 2 nodes" with linespoints lc 4 \
    ,"all_4.out" using 1:2 title "MPI 4 nodes" with linespoints lc 6 \
    ,"all_8.out" using 1:2 title "MPI 8 nodes" with linespoints lc 8 \

pause 10
EOF

