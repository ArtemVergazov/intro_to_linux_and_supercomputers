#include <stdio.h>
#include <time.h>
#include <stdlib.h>
#include <omp.h>
#include <mm_malloc.h>

#ifndef SINGLE
#define MATRIX_L1 36              // L1=32768 bytes
#define MATRIX_L2 200             // L2=1,048,576 bytes
#define MATRIX_L3 1000            // L3=25,952,256 bytes
#define MATRIX_MM 4000            // Mem > L3=25,952,256 bytes
#else
#define MATRIX_L1 52      	  // L1=32768 bytes
#define MATRIX_L2 295             // L2=1,048,576 bytes
#define MATRIX_L3 1470            // L3=25,952,256 bytes
#define MATRIX_MM 5000            // Mem > L3=25,952,256 bytes
#endif

#define GENSEED         1235791         // prime random seed

#define CLOCK_MY CLOCK_REALTIME

#define NANOSEC_in_SEC 1000000000LL
#define dseconds(tx,ty)  ((double)((ty.tv_sec)-(tx.tv_sec))*1.0+(double)((ty.tv_nsec)-(tx.tv_nsec))/NANOSEC_in_SEC)
#define dmicrosec(tx,ty) ((double)((ty.tv_sec)-(tx.tv_sec))*1000000.0+(double)((ty.tv_nsec)-(tx.tv_nsec))/1000.0)
#define llnanosec(tx,ty) ((long long unsigned) (ty.tv_sec - tx.tv_sec) * NANOSEC_in_SEC + (long long unsigned)(ty.tv_nsec - tx.tv_nsec))

#define MBYTES (1024*1024)
#define PAGESIZE 4096
#define CACHE_LINE_SIZE 64
#define IOPAGESALIGN    (PAGESIZE - 1)
#define IOCACHEALIGN    (CACHE_LINE_SIZE - 1)
static inline void * _cachealign(void *p, size_t len) {
              return (void *) (((unsigned long long) p + len + IOCACHEALIGN) & ~((unsigned long long) IOCACHEALIGN));
               }
static inline void * _pagesalign(void *p, size_t len) {
              return (void *) (((unsigned long long) p + len + IOPAGESALIGN) & ~((unsigned long long) IOPAGESALIGN));
               }

#ifdef DOUBLE
#define PRECISION   "DOUBLE"
typedef double mmx_t;     // matrix element type for DOUBLE
#else
#define PRECISION   "SINGLE"
typedef float mmx_t;      // matrix element type for SINGLE
#endif

typedef mmx_t ** matrix_t;
typedef mmx_t *  rowmat_t;

/*
typedef struct matrix {  
    mx_t v[MATRIX_N][MATRIX_N];
} matrix_t;
*/

long getparams(int argc, char *argv[]);
void clocktest();
void matalloc(long n, matrix_t *, matrix_t *, matrix_t *);
void matinit(long , matrix_t, matrix_t, matrix_t);
void matprint(long , matrix_t, matrix_t, matrix_t);
int  matmul(long , matrix_t restrict , matrix_t restrict , matrix_t restrict , char **ident);


