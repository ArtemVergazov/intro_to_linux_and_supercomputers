#!/usr/bin/bash

echo "run: . setenv"
module load compilers/gcc-7.3.1
module load compilers/intel
module load gpu/cuda-11.3

# Changed this to fix the bug with random matrix initialization.
export OMP_NUM_THREADS=4
export MKL_NUM_THREADS=4

which icc
