#!/usr/bin/bash

gnuplot <<EOF

set key top left

set size 1,1
set origin 0,0
set terminal x11 font "Helvetica, 12"

set xlabel "Number of threads"
set xrange [0:17]
set xtics 1

set ylabel "Performance, Mflop/s"
set yrange [0:2500000]
#set ytics 2

plot "single.dat" u 2:1 t "CPU, single precision, N=30000" pt 5 ps 3 w p, "double.dat" u 2:1 t "CPU, double precision, N=30000" pt 4 ps 3 w p 

pause 10
EOF

