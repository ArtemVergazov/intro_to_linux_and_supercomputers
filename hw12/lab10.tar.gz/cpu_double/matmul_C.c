#include <stdio.h>
#include <time.h>
#include <stdlib.h>
#include <omp.h>
#include <mm_malloc.h>

#include "matmul.h"

int matmul(long n, matrix_t restrict a, matrix_t restrict b, matrix_t restrict c, char **ident)
{ 
    int nthreads = omp_get_max_threads();

    long long int i,j,k;
#pragma omp parallel for simd aligned(a,b,c:64) default(none) private(j,k) firstprivate(n) shared(a,b,c)
    for(i=0; i<n; i++) 
        for(j=0; j<n; j++) 
            for(k=0; k<n; k++) 
                c[i][j] += a[i][k] * b[k][j];

    *ident = __FILE__;
    return nthreads;
}

