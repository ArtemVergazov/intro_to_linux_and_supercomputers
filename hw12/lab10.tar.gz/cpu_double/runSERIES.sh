#!/usr/bin/bash

time="20:00"
mem=21G
#queue=cpu
queue=htc

for threads in 1 #2 #4 8 16
do
    cpus=$threads
    mincpus=$((cpus+1))
    echo "submit $queue output=MKL_${cpus}.out -N 1 -n 1 -c $cpus --mincpus=$cpus --mem=$mem --time=$time"

    sbatch -J matmulMKL-${cpus} -p $queue --output=MKL_${cpus}.out -N 1 -n 1 -c $cpus \
                                                --mincpus=$cpus --mem=$mem --time=$time runMKL.sh
    sleep 5
done
echo END

