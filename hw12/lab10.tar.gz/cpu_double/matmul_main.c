#include <stdio.h>
#include <time.h>
#include <stdlib.h>
#include <omp.h>
#include <mm_malloc.h>

#include "matmul.h"

int main(int argc, char *argv[])
{
	struct timespec t1, t2;
    double dtinit, dtrun, dtruns, dperf;
    long long int n = getparams(argc, argv);

    long long int FLOPS = 2 * n * n * n;

    long long int iter = 0;
    int nthreads = 1;
    char *ident;

    matrix_t a, b, c;

    double s=0;
	int i=0;

    matalloc(n, &a, &b , &c);
    matinit(n, a, b, c);
    matprint(n, a, b, c);

    iter=0;
	/* start timing region */
    clock_gettime(CLOCK_MY, &t1);
    do { // run the loop for at least 10 seconds

        nthreads = matmul(n, a, b, c, &ident);

	    /* end timing region */
	    clock_gettime(CLOCK_MY, &t2);
        iter++;
        dtruns = dseconds(t1,t2);
        if(n <= 10 ) dtruns = 10; //for debugging
    }while(dtruns < 10);

    matprint(n, a, b, c);
    dperf  = iter * FLOPS/dmicrosec(t1,t2);
	printf("%16s %s: matmul_N %6d elapsed[s]: %6.2f Perf[MFlop/s]: %10.2f T/iter[s] %10.2e  with %4d iterations; Threads: %3d\n",
                    ident,PRECISION,n, dtruns, dperf, dtruns/iter, iter, nthreads);

    return 0;
}
