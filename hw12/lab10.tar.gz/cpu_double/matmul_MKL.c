#include <stdio.h>
#include <time.h>
#include <stdlib.h>
#include <time.h>
#include <omp.h>
#include <mkl.h>
#include <mm_malloc.h>

#include "matmul.h"


int  matmul(long ndim, matrix_t restrict a, matrix_t restrict b, matrix_t restrict c, char **ident)
{
    mmx_t  alpha = 1.0;
    mmx_t  beta  = 0.0;
    int n = ndim;
    int nthreads = mkl_get_max_threads();
        
#ifdef DOUBLE
    cblas_dgemm(
#else
    cblas_sgemm(
#endif
                CblasRowMajor, CblasNoTrans, CblasNoTrans, 
                            n, n, n, alpha, &a[0][0], n, &b[0][0], n, beta, &c[0][0], n);

    *ident = __FILE__;
    return nthreads;
}
