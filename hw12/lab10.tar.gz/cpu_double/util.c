/*   
 *   Project "Performance of Matrix Multiplication"
 *   utility programs
 *
 *   created     author     comments
 *   10/12/2021  I.Zacharov initial release
 */
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <time.h>
#include <mm_malloc.h>

#include "matmul.h"

#define OPTFLAGS	"l:s:"

const char optflags[] = OPTFLAGS ;   //option flags

void usage(int argc, char *argv[])
{
        fprintf(stderr,"usage: %s [-%c <1/2/3/m>] [-%c <size>]\n",argv[0],optflags[0],optflags[2]);
        exit(0);
}
long getparams(int argc, char *argv[])
{
        const char *flags = optflags;
        char *param = NULL;
        int opt, opt2;
        extern char * optarg;
        long par1 = MATRIX_MM;
        int pflag = 0;

    while ( (opt = getopt(argc, argv, flags)) != -1 ) {
                if ( opt == optflags[0] ) {    
                     param = optarg;
                     opt2 = param[0];
                     switch (opt2) {
                     case '1': par1 = MATRIX_L1; break;
                     case '2': par1 = MATRIX_L2; break;
                     case '3': par1 = MATRIX_L3; break;
                     case 'm': par1 = MATRIX_MM; break;
                     default: usage(argc,argv); exit(1);
                     }
		}
		else if ( opt == optflags[2] ) {   
                     param = optarg;
                     par1 = atoll(param);
		}
		else {
		     usage(argc, argv);
		     break;
		}	
	}
    //fprintf(stderr,"size: %ld\n",par1);
    return par1;
}

void clocktest()
{
    struct timespec t1, t2;
    long long unsigned diffns;
    long i = 0;

    clock_gettime(CLOCK_MY, &t1); t2.tv_nsec = t1.tv_nsec;
    while( t2.tv_nsec <= t1.tv_nsec) { clock_gettime(CLOCK_MY, &t2); i++; }
    diffns = llnanosec(t1,t2);
    printf("clock resolution: %lld ns  Overhead: %f ns loopcount: %d\n", diffns, (double)diffns/i, i);

}

