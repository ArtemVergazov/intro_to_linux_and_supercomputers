#!/usr/bin/bash

gnuplot <<EOF

set size 1,1
set origin 0,0
set terminal x11 font "Helvetica, 12"

set xlabel "OMP threads"
set xrange [1:8]
set xtics 1

set ylabel "Real time elapsed, s"
set yrange [0:100]
#set ytics 2

plot "MPI_1.dat" u 2:3 t "1 MPI thread" lc 1 with linespoints, "MPI_2.dat" u 2:3 t "2 MPI threads" lc 2 with linespoints, "MPI_4.dat" u 2:3 t "4 MPI threads" lc 4 with linespoints, "MPI_8.dat" u 2:3 t "8 MPI threads" lc 8 with linespoints

pause 20
EOF

