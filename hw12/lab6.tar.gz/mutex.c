/* Iosif Leibin, 02.12.2021
    This is the program for LabX-6(3)
    It showcases the use of mutex for
    dealing with the race condition.
    "myheader.h" contains preprocessor directives,
    among which are the definitions of NITER (constatnt for designating
    how long each thread will take to finish its work) and
    MAX_NTHRS (the maximum number of threads)

    No input or option required, but you can specify the number of threads:

    export NUM_THREADS
    NUM_THREADS=n (2 < n < MAX_THREADS)
    gcc -o mutex mutex.c -pthread ; ./mutex
*/

#include "myheader.h"

long long int sum = 0;
pthread_mutex_t mutex = PTHREAD_MUTEX_INITIALIZER;

void* func(void* arg) {
    const long n = * (long*)arg; // Taking the value at which points arg, while converting it to long int*
	long i;
    for (i=0; i<NITER; i++) {
	    pthread_mutex_lock(&mutex);
	    //sem_wait(&sem);

	    sum += n;

	    //sem_post(&sem);
	    pthread_mutex_unlock(&mutex);
    }
    pthread_exit(NULL);
}

int main(int argc, char **argv) {
    long na[MAX_NTHRS];
    pthread_t tid[MAX_NTHRS];
    pthread_attr_t attr;

    int nth = 1;
    char* cnth = getenv("NUM_THREADS");

    if(cnth) nth = atoi(cnth); // If number of threads was received from outside
    if(nth < 0 || nth >= MAX_NTHRS) nth = 2; // If received incorrectly;

    if (pthread_attr_init(&attr)) {
	    perror("attr_init");
	    return 1;
    }

    printf ("Starting %i threads", nth);
    int i;
	for (i=0; i< nth; i++) {
	    na[i] = (i & 1)? -1: 1; // Using bitwise AND, basically if i%2 == 0, then nth = 1, otherwise -1
	    if (pthread_create(&(tid[i]), &attr, func, &(na[i]))) {
		    perror("thr_crt");
		    return 2;
	    }
	    printf ("\t[ %d: %lx %ld ]", i, tid[i], na[i]);
    }
    printf("\n");

    for(i=0; i<nth; i++) {
	    if (pthread_join(tid[i], NULL)) {
		    perror("trh_join");
		    return 3;
	    }
    }

    printf ("sum = %ld\n", sum);
    printf ("All done\n");
    return 0;
}
