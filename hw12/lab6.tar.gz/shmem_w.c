/* Iosif Leibin, 02.12.2021
    This is the program for LabX-6(2).
    It writes to the shared memory segment
    and prints what it contains afterwards.
    It requires no arguments of options, but after launch one
    should enter the string that is to be written to th shared memory

    Launch: ./shmem_w
    > Input string
*/

#include "stdio.h"
#include "stdlib.h"
#include "unistd.h"
#include "string.h"
#include "sys/types.h"
#include "sys/wait.h"
#include "sys/ipc.h"
#include "sys/shm.h"

#define SHMKEY  3223
#define SHMSIZE 1024
#define BUFSIZE 128

int main(int argc, char **argv) {
    key_t key;
    size_t size;
    int shmid;
    void* shared_memory;
    char buff[BUFSIZE];

    if (shmid = shmget((key_t) SHMKEY, SHMSIZE, 0666|IPC_CREAT) < 0) { // Get an identifier for a shared memory segment size SHMSIZE under the SHMKEY
        perror("shmget");
        return 1;
    }
    if ( (shared_memory = shmat(shmid, NULL, 0)) == (void*)(-1) ) { // Get the adress of the shared memory segment
        perror("shmat");
        return 1;
    }

    fgets(buff, BUFSIZE, stdin);
    strcpy(shared_memory, buff);

    printf ("Writing to shmem key %i, id: %x, string: %s \n", SHMKEY,shmid,buff);
    printf ("All done\n");
    return 0;
}
