/* Iosif Leibin, 02.12.2021
    This is the program for LabX-6(1)
    It creates two processes, parent and child, which
    send data to each other through a pipe
    Data is taken from the stdin by the parent and is sent to the child, which
    prints it to stdout.
    Data is sent in a form of symbolic strings

    Launch:
    ./pipe_p2c
    No input, no flags
*/

#include "stdio.h"
#include "stdlib.h"
#include "unistd.h"
#include "string.h"
#include "sys/types.h"
#include "sys/wait.h"
#include "sys/stat.h"

#define SIZEBUF 128
#define NOUTLINES 30

int main(int argc, char **argv) {
    int pfd[2];

    if(pipe(pfd) != 0) {
        perror("pipe_init");
        return 1;
    }
    pid_t pid;

    if ( (pid = fork()) < 0 ) {
	    perror("fork");
	    return 1;
    }

    if(pid) close(pfd[0]); // If parent, close write
    else    close(pfd[1]); // If child, close read

    while(1) {
	    char inchar[SIZEBUF] = {'0'};
	    inchar[0] = '\0';

	    int n;
	    if (pid) { // Parent
            if (fgets (inchar, SIZEBUF, stdin)) {
                if (strlen(inchar) == 1) continue; // ignoring empty input
                n = write(pfd[1], inchar, strlen(inchar));
                printf ("%6d  send %s \tn=%d\n", pid, inchar, n);
                sleep(1);
            }
            else {
                fprintf(stderr, "Failed to read from stdin\n");
                break;
            }
	    }
	    else { // Child
            if ( (n = read(pfd[0], inchar, SIZEBUF)) > 0 ) {
                inchar[n] = '\0'; // So printf() would stop putting bytes in the stdout after the sent data,
                              // since the inchar[] may contain symbols from prevous communications
                if(strlen(inchar) == 1) continue;
                else printf ("%6d   got %s \tn=%d\n", pid, inchar, n);
            }
            else { // Stopping the program
                fprintf(stderr, "Failed to get data from pipe\n");
                break;
            }
	    }
    }
    printf ("All done\n");
    return 0;
}
