/* Iosif Leibin, 18.11.2021
    This is the program for LabX-6(3)
    It is supposed to demonstrate the race condition
    Two threads are created, both work with the same static variable
    for a long time. As a result, som of th work that is supposed to
    be done with this variable, is not done

    Launch:
    gcc -o pthr pthr.c -pthread ; ./pthr
*/

#include "stdio.h"
#include "stdlib.h"
#include "pthread.h"

#define NITER 5000000 // When NITER < 500 there is no race, one thread ends its work long before the other one starts

static long long sum = 0;

void *func(void * arg) {
    long n = *(long *)arg; // Taking the value at which points arg, while converting it to long int*
    printf ("func called\n");
    for (long int i=0; i<NITER; i++) {
	    sum += n;
    }
    //printf ("Sum end\n");
    pthread_exit(NULL);
    //printf ("Exited\n");
}

int main(int argc, char **argv) {
    long n1 =  1;
    long n2 = -1;
    pthread_t tid1, tid2;
    pthread_attr_t attr;

    printf ("Creating two threads\n");

    if ( pthread_attr_init(&attr) != 0) perror("pthrd_attr_init");
    if ( pthread_create(&tid1, &attr, func, &n1) != 0 ) perror("pthrd1_create"); // This thread increases the sum variable
    else printf ("Thread 1 created\n");

    if ( pthread_create(&tid2, &attr, func, &n2) != 0 ) perror("pthrd2_crt"); // While this one decreases it, the net result should be zero
    else printf ("Thread 2 created\n");

    //printf ("Joining\n");
    if (pthread_join(tid1, NULL) != 0) perror("pthrd1_jn"); // Waiting for the threads to finish work.
    else printf ("Thread 1 finished\n");

    if (pthread_join(tid2, NULL) != 0) perror("pthrd2_jn");
    else printf ("Thread 2 finished\n");

    printf ("sum = %lld\n", sum);
    printf ("All done\n");
    return 0;
}
