#!/usr/bin/bash

export NUM_THREADS
	
for t in 1 2 4 6 
do
	NUM_THREADS=$t
	echo "$t threads"

	echo "Mutex:"
	time ./mutex > junk
	
	echo "Sem:"
	time ./sem > junk
	
	echo "Atomic:"
	time ./atomic >junk
done
