/* Iosif Leibin, 20.11.2021
    This is the program for LabX-6(2)
    It reads from a shared memory with a key SHMKEY
    and prints what it contains
*/

#include "stdio.h"
#include "stdlib.h"
#include "unistd.h"
#include "string.h"
#include "sys/types.h"
#include "sys/wait.h"
#include "sys/ipc.h"
#include "sys/shm.h"

#define SHMKEY  3223
#define SHMSIZE 1024
#define BUFSIZE 128

int main(int argc, char **argv) {
    key_t key;
    size_t size;
    int shmid;
    void* shared_memory;
    char buff[BUFSIZE];

    if (shmid = shmget((key_t) SHMKEY, SHMSIZE, 0666|IPC_CREAT) < 0) { // Get an identifier for a shared memory segment size SHMSIZE under the SHMKEY
        perror("shmget");
        return 1;
    }
    if ( (shared_memory = shmat(shmid, NULL, 0)) == (void*)(-1) ) { // Get the adress of the shared memory segment
        perror("shmat");
        return 1;
    }

    strcpy(buff, shared_memory); // Read from the shared memory segment

    printf ("Reading from shmem key %i, id: %x\nIt contents: %s \n", SHMKEY,shmid,buff);
    printf ("Deleting shared memory...\n");

    shmctl(shmid, IPC_RMID, NULL);

    printf ("All done\n");
    return 0;
}
