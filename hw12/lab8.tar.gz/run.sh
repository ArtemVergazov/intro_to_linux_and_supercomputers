#!/usr/bin/bash

export OMP_NUM_THREADS=2;

NP=$1

mpirun -np $NP -mca btl_base_warn_component_unused 0 ./piprog_MPI
