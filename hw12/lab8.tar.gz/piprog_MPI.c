/* Iosif Leibin, 16.12.2021
    This is the program for LabX-7(2)
    It calculates the value of pi,
    using random number generator. It can be parallelized
    with MPI. The folder contains run.sh script, which
    takes in the number of MPI processes should, compiles and
    runs the program:

    ./run.sh 8

    Number of OMP threads is 4 by default, but an be changed in run.sh
*/

#include "mpi.h"
#include "time.h"
#include "stdio.h"
#include "math.h"
#include "stdlib.h"
#include "omp.h"

#define NPOINTS 400000000
#define GENSEED 890789

#define NANOSEC_in_SEC 1000000000LL
#define dsecond(tx, ty) ((double)((ty.tv_sec)-(tx.tv_sec))+(double)((ty.tv_nsec)-(tx.tv_nsec))/NANOSEC_in_SEC)

int main(int argc, char** argv) {
	unsigned long long ncirc = 0;
	double pi, dpi;
	int omp_nthrds, numthrd, mythrd_id, rank, size;
	unsigned long long num_trials = NPOINTS;
	struct timespec tstart, tend;

	char* omp;
	if ((omp = getenv("OMP_NUM_THREADS")) != NULL) {
		printf ("getting n threads from external: %i\n", atoi(omp));
		omp_nthrds = atoi(omp);
		if (omp_nthrds > omp_get_max_threads() || omp_nthrds < 1) {
			printf ("Wrong nthrds = %i // %i\n", omp_nthrds, omp_get_max_threads());
			omp_nthrds = 1;
		}
	}


	MPI_Init(&argc, &argv);
	MPI_Comm_size(MPI_COMM_WORLD, &numthrd);
	MPI_Comm_rank(MPI_COMM_WORLD, &mythrd_id);

	clock_gettime(CLOCK_REALTIME, &tstart);
	unsigned long long local_ncirc = 0;

#pragma omp parallel default(none) firstprivate(num_trials, mythrd_id) shared(local_ncirc)
{
	unsigned long long local_local_ncirc = 0; // local_ncirc - for one MPI process, local_local* - for one thread
	unsigned long long i;
	int mythread = omp_get_thread_num();
	long rseed = (mythread+10*mythrd_id)*GENSEED; // seed should be different for all threads in all MPI processes, if mythread and mythrd_id < 10, this simple scheme works
	struct drand48_data rbuf;
	srand48_r(rseed, &rbuf);
	double x, y, t, dres1, dres2;

	for(i=0; i<num_trials; i++) {
		drand48_r(&rbuf, &dres1);
		drand48_r(&rbuf, &dres2);

		x = 2.0*dres1 - 1;
		y = 2.0*dres2 - 1;
		t = x*x + y*y;

		if (t <= 1.0) local_local_ncirc++;
	}
	#pragma omp atomic
	local_ncirc += local_local_ncirc;
} // end parallel region

	MPI_Reduce(&local_ncirc, &ncirc, 1, MPI_LONG_LONG_INT, MPI_SUM, 0, MPI_COMM_WORLD);

	clock_gettime(CLOCK_REALTIME, &tend);
	double tlaps = dsecond(tstart,tend);

	num_trials *= numthrd*omp_nthrds;
	pi = 4.0 * (double) ncirc/(double) num_trials;
	dpi = pi*sqrt(2.0/num_trials);

	printf ("pi %.8f dp  %.lg \n", pi, dpi);

	MPI_Finalize();
	return 0;
}

