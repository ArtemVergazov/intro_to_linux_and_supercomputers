#!/usr/bin/bash

#export OMP_MCA_btl_base_warn_component_unused=0
export OMP_NUM_THREADS=4;

module load mpi/openmpi-3.1.2
