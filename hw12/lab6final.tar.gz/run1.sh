#!/usr/bin/bash

for x in 1 2 3 4
do
    echo $x
done

