#!/usr/bin/bash
# A script for LabX-7(2e). It looks for the Ntrials value that
# would raise the worktime on 1 processor to 5 mins

export OMP_NUM_THREADS=1
ntrials=1000000
t=0

while [ 300 -gt $t ] 
do
	ntrials=$((ntrials*5))
	echo "Ntrials: $ntrials"

	output=$( ./piprog_G -t $ntrials | grep Elapsed )
	echo "Raw: $output"

	out=$( echo $output | cut -d "," -f 4 )
	echo "Time: $out"	
	
	ot=$( echo $out | cut -d " " -f 2 )
	echo "Seconds: $ot"
	
	t=$(echo "scale=0; $ot/1" | bc)
	echo "Elapsed time: $t s"
done
