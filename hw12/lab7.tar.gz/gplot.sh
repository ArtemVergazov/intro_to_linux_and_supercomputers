#!/usr/bin/bash

#awk '/elapsed/{threads=$15; perf=$8/1000.0; print threads, perf }' *.out | sort -n >allout

cat times.dat > pltdat

gnuplot <<EOF

set size 1,1
set origin 0,0
set terminal x11 font "Helvetica, 12"

set xlabel "number of threads"
set xrange [1:4]
set xtics 1
set ylabel "Time, s"
set yrange [0:12]
#set ytics 2

plot "pltdat" u 1:2 t "Elapsed (subm.)" lc 6 with linespoints, "pltdat" u 1:3 t "Elapsed (int.)" lc 4 with linespoints, "pltdat" u 1:4 t "cmd_real (int.)" with linespoints lc 7, "pltdat" u 1:5 t "cmd_user" with linespoints lc 2

pause 10
EOF

rm pltdat
