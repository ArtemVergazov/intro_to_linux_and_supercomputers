#!/usr/bin/bash

#SBATCH --output piprog_A_%j.out
#SBATCH --partition=cpu
#SBATCH --nodes=1
#SBATCH --cpus-per-task=4
#SBATCH --time=10:00
#SBATCH --mem-per-cpu=10M

./piprog_A -t 1000000000 | grep Elapsed
