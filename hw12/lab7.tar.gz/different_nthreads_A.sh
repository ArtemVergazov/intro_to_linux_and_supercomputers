#!/usr/bin/bash
# Script for LabX-7(2a). Running the ./piprog
# with a different number of threads and
# writing how much timw it did take

export OMP_NUM_THREADS=1

for x in 1 2 4 6
do
	OMP_NUM_THREADS=$x
	echo "------------------------------"
	echo "$x threads"
	sbatch runpi.sh
	time ./piprog_A -t 1000000000 | grep Elapsed
done
