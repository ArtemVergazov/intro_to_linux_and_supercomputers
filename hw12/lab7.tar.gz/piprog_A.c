/* Iosif Leibin, 02.12.2021
    This is the program for LabX-7(2)
    It calculates the value of pi,
    using random number generator. It can be parallelized
    with OpenMPI. Number of threads is 1 unless external variable OMP_NUM_THREADS
    is specified. Workload is distributed in the main "for"-loop of the algorythm
    Two command line flags are realized: -s <ll int> and -t <ll int>. The first one
    reads seed value for the random number generator, the second one reads
    the number of points to be randomly "thrown" at the circle
    and is proportional to the accuracy of pi calculation

    Launch:
    export OMP_NUM_THREADS
    OMP_NUM_THREADS=n (2 < n < MAX_THREADS)
    gcc -o piprog -fopenmp -O3 piprog_A.c -lm ; ./piprog -t NPOINTS -s SEED
*/

#include "stdio.h"
#include "stdlib.h"
#include "omp.h"
#include "math.h"
#include "unistd.h"

//-------------------------------------

#define OPT_FLAGS "s:t:"

//-------------------------------------

long long NPOINTS = 100000; // Default values
unsigned long long GENSEED = 9529591;

extern int optind;
extern char* optarg;

//------------------------------------

int GetOptFlags(int argc, char ** argv) {
	char* farg = NULL;
	char flag = '\0';
	const char flags[] = OPT_FLAGS;

	while((flag = getopt(argc, argv, flags)) != -1) {
		switch(flag) {
			case 's':
				if (atoll(optarg) < 1) {
					printf("Error in reading seed\n");
					GENSEED = 1;
				}
				else GENSEED = atoll(optarg);
				printf ("Seed: %lld\n", atoll(optarg));
				break;
			case 't':
				if (atoll(optarg) < 1) {
					printf ("Error in reading n_points\n");
					NPOINTS = 1;
				}
				else NPOINTS = atoll(optarg);
				printf ("N_points: %lld\n", atoll(optarg));
				break;
			default:
				return 0;
		}
	}
	return 1;
}

//------------------------------------

int main(int argc, char** argv) {
	long long ncirc = 0;
	double pi, dpi;
	int n_thrds = 1;
	char* omp;
	if ((omp = getenv("OMP_NUM_THREADS")) != NULL) {
		n_thrds = atoi(omp);
		if (n_thrds > omp_get_max_threads() || n_thrds < 1) {
			n_thrds = 1;
		}
	}

	double tstart = omp_get_wtime();

	if(!GetOptFlags(argc, argv)) return 1;
	unsigned long long n_points = NPOINTS;

#pragma omp parallel default(none) firstprivate(n_points, GENSEED) shared(ncirc)
{
	double x,y,t,dres1,dres2;
	struct drand48_data rbuf;
	int mythread = omp_get_thread_num();
	long rseed = (mythread+1) * GENSEED;
	unsigned long long i=0;

	srand48_r(rseed, &rbuf);

	#pragma omp for reduction(+:ncirc)
	
	for (i=0; i<n_points; i++) { // Workload is disributed
		drand48_r(&rbuf, &dres1);
		drand48_r(&rbuf, &dres2);

		x = 2.0 * dres1 - 1;
		y = 2.0 * dres2 - 1;
		t = x*x + y*y;

		if (t <= 1.0) ncirc++;
	}
} // end parallel
	double tend = omp_get_wtime();
	double tlaps= tend - tstart;

	if(NPOINTS == 1) tlaps = 1000000; // So the time measuring script does not run infinitely when things went wrong on the input

	pi = (long double) 4.0 * (long double) ncirc / (long double) n_points;
	dpi = pi*sqrt(2.0/(long double)n_points);
	printf ("Points_thrown: %lld, Ncirc: %lld Threads: %d, Elapsed: %.2f PI: %.8lf dpi: %.lg\n", n_points, ncirc, n_thrds, tlaps, pi, dpi);

	return 0;
}

